# Welcome to Farmer's Market!
[![Build Status](https://travis-ci.org/ericdunham/farmers-market.svg?branch=master)](https://travis-ci.org/ericdunham/farmers-market)
[![Code Climate](https://codeclimate.com/github/ericdunham/farmers-market/badges/gpa.svg)](https://codeclimate.com/github/codeclimate/codeclimate)
[![Coverage Status](https://coveralls.io/repos/github/ericdunham/farmers-market/badge.svg?branch=master)](https://coveralls.io/github/ericdunham/farmers-market?branch=master)

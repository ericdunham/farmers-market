# -*- coding: utf-8 -*-
major = 0
minor = 0
patch = 1
semantic = '{}.{}.{}'.format(major, minor, patch)
